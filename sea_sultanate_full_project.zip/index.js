// Core Booking Engine API - Node.js (Express + PostgreSQL)

const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');

const app = express();
app.use(bodyParser.json());

const db = new Pool({
  user: 'youruser',
  host: 'yourdbhost',
  database: 'seasultanate',
  password: 'yourpassword',
  port: 5432,
});

// --- ROUTES --- //

// 1. Book Transfer
app.post('/book', async (req, res) => {
  const { userId, tripId, passengers, paymentMethod } = req.body;
  try {
    const booking = await db.query(
      'INSERT INTO bookings(user_id, trip_id, passengers, payment_method, status) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [userId, tripId, passengers, paymentMethod, 'pending']
    );
    res.json({ success: true, booking: booking.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error processing booking');
  }
});

// 2. Cancel Booking
app.post('/cancel', async (req, res) => {
  const { bookingId } = req.body;
  try {
    await db.query('UPDATE bookings SET status = $1 WHERE id = $2', ['cancelled', bookingId]);
    res.json({ success: true, message: 'Booking cancelled' });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error cancelling booking');
  }
});

// 3. View Seat Availability
app.get('/seat-view/:tripId', async (req, res) => {
  const { tripId } = req.params;
  try {
    const result = await db.query(
      `SELECT t.total_seats, 
              (SELECT COUNT(*) FROM bookings WHERE trip_id = $1 AND status = 'confirmed') AS booked_seats
       FROM trips t WHERE t.id = $1`,
      [tripId]
    );
    const { total_seats, booked_seats } = result.rows[0];
    res.json({
      tripId,
      total_seats,
      booked_seats,
      available_seats: total_seats - booked_seats
    });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error checking seat availability');
  }
});

// --- Server Start --- //
app.listen(3000, () => {
  console.log('🚤 Booking Engine running on port 3000');
});
